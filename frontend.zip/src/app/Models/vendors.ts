export interface Vendors {
    _id?: string;
    Name: string; 
    email: string;
    phoneNumber: string; 
    address: string; 
    role: string; 
    password: string; 
  }
  