export interface Offers {
    
    _id:string;
    offer:string;
    restaurantId:string;
    restaurantName:string
}
