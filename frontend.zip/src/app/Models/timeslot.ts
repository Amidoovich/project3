// Assuming TimeslotResponse contains an array of Timeslot objects
export interface Timeslot {
  _id: string;
  time: string;
}

// export interface Timeslot {
//   _id: string;
//   time: string;
//   restaurantId: string;
//   // other relevant properties
// }
